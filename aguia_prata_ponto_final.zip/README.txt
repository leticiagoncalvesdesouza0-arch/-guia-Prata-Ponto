ÁGUIA PRATA — SISTEMA DE PONTO

1. Publique o index.html.
2. Antes de usar, configure URL_SUPABASE e ANON_KEY no index.html.
3. Use somente a chave pública anon/publishable. Nunca use service_role/sb_secret no navegador.
4. A autenticação precisa ter os usuários criados no Supabase Auth.
5. O site usa a geolocalização do navegador no momento da batida.

Funcionários:
- Marcelo / marcelo
- Marta Gomes / marta
- Matheus Melli / matheus
- Sérgio Melli / sergio
