-- ÁGUIA PRATA | Estrutura inicial do banco de dados
-- Compatível com PostgreSQL/Supabase (ajuste conforme o provedor escolhido).

create table if not exists employees (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  username text unique not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists time_entries (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references employees(id),
  entry_type text not null check (entry_type in ('Entrada','Início do intervalo','Fim do intervalo','Saída')),
  recorded_at timestamptz not null default now(),
  latitude double precision not null,
  longitude double precision not null,
  gps_accuracy_m double precision,
  created_at timestamptz not null default now()
);

insert into employees (name, username) values
('Marcelo','marcelo'),
('Marta Gomes','marta.gomes'),
('Matheus Melli','matheus.melli'),
('Sérgio Melli','sergio.melli')
on conflict (username) do update set name=excluded.name, active=true;
